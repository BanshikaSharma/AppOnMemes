import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCSHo9LXdGOrVTwKNxYBiBUD5MjXArF9Og",
  authDomain: "chatappbot-b973a.firebaseapp.com",
  projectId: "chatappbot-b973a",
  storageBucket: "chatappbot-b973a.firebasestorage.app",
  messagingSenderId: "751919938363",
  appId: "1:751919938363:web:c5e130f0acf4d35257951e",
  measurementId: "G-MYS4GB4L8D"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);