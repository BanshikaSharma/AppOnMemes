// app.js
const chatContainer = document.getElementById('chat-container');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');
const loginButton = document.getElementById('login-button');
const logoutButton = document.getElementById('logout-button');

let user = null;

// Login with Google
loginButton.addEventListener('click', async () => {
    const provider = new firebase.auth.GoogleAuthProvider();
    try {
        const result = await auth.signInWithPopup(provider);
        user = result.user;
        loginButton.style.display = 'none';
        logoutButton.style.display = 'block';
    } catch (error) {
        console.error("Error during sign-in:", error);
    }
});

// Logout
logoutButton.addEventListener('click', async () => {
    await auth.signOut();
    user = null;
    loginButton.style.display = 'block';
    logoutButton.style.display = 'none';
});

// Send message
sendButton.addEventListener('click', async () => {
    const message = messageInput.value;
    if (message && user) {
        await db.collection('messages').add({
            text: message,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            uid: user.uid,
            displayName: user.displayName
        });
        messageInput.value = '';
    }
});

// Fetch messages
db.collection('messages').orderBy('createdAt').onSnapshot(snapshot => {
    chatContainer.innerHTML = '';
    snapshot.forEach(doc => {
        const message = document.createElement('div');
        message.textContent = `${doc.data().displayName}: ${doc.data().text}`;
        chatContainer.appendChild(message);
    });
});