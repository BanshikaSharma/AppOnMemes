from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/signin')
def signin():
    return render_template('signin.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/getstarted')
def getstarted():
    return render_template('getstarted.html')

@app.route('/inbox')
def inbox():
    return render_template('inbox.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')  # New route for the profile page

@app.route('/videos')
def videos():
    return render_template('videos.html')  # New route for the videos page

@app.route('/memehouse')
def memehouse():
    return render_template('memehouse.html')  # New route for the Meme House page

@app.route('/videoshort')
def videoshort():
    return render_template('videoshort.html')  # New route for the Video Shorts page

@app.route('/redirect_to_index')
def redirect_to_index():
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)